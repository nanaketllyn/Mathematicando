# AlgebraLinear/Semana13

Subdiretório com o material referente ao capítulo "Semana 14" do livro "Álgebra Linear - Um Livro Colaborativo".

## Contato

<livroscolaborativos@gmail.com>

## Licença

Este trabalho está licenciado sob a Licença Creative Commons Atribuição-CompartilhaIgual 3.0 Não Adaptada. Para ver uma cópia desta licença, visite https://creativecommons.org/licenses/by-sa/3.0/ ou envie uma carta para Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.